package com.mycompany.mypudingapp.admin.Service;


import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mycompany.mypudingapp.admin.Mapper.AdminMapper;
import com.mycompany.mypudingapp.admin.vo.AdminDVO;
import com.mycompany.mypudingapp.admin.vo.admin_boardVO;
import com.mycompany.mypudingapp.domain.Criteria;
import com.mycompany.mypudingapp.domain.PagingVO;


@Service
public class AdminService {

	@Autowired
	private AdminMapper adminMapper;

	public List<admin_boardVO> adm_list(PagingVO vo) {
		return adminMapper.adm_list(vo);
	}
	
	public int countBoard() {
		return adminMapper.countBoard();
	}

	public admin_boardVO adm_viewDetail(int admin_seq) {
		return adminMapper.adm_viewDetail(admin_seq);
	}

	public void adm_insert(@Param("admin_title")String admin_title,@Param("admin_writer")String admin_writer,@Param("admin_content")String admin_content) {
		adminMapper.adm_insert(admin_title,admin_writer,admin_content);
	}

	public void adm_doupdate(@Param("admin_seq")int admin_seq,@Param("admin_title")String admin_title,@Param("admin_writer")String admin_writer,@Param("admin_content")String admin_content) {
		adminMapper.adm_doupdate(admin_seq,admin_title,admin_writer,admin_content);
	}

	public void adm_delete(int admin_seq) {
		adminMapper.adm_delete(admin_seq);
	}

	public AdminDVO adm_login(AdminDVO aVO) {
		return adminMapper.adm_login(aVO);
	}

	public int listCount() {
		return adminMapper.listCount();
	}
//	
//	public List<admin_boardVO> selectList(PagingVO pg) {
//		return adminMapper.selectList(pg);
//	}
	
}
