package com.mycompany.mypudingapp.admin.Mapper;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.mycompany.mypudingapp.admin.vo.AdminDVO;
import com.mycompany.mypudingapp.admin.vo.admin_boardVO;
import com.mycompany.mypudingapp.domain.PagingVO;

public interface AdminMapper {

	public List<admin_boardVO> adm_list(PagingVO vo);
	
	public int countBoard();

	public admin_boardVO adm_viewDetail(int admin_seq);

	public void adm_insert(admin_boardVO dto);

	public void adm_insert(@Param("admin_title")String admin_title,@Param("admin_writer")String admin_writer,@Param("admin_content")String admin_content);


	public void adm_doupdate(@Param("admin_seq")int admin_seq,@Param("admin_title")String admin_title,@Param("admin_writer")String admin_writer,@Param("admin_content")String admin_content);

	public void adm_delete(int admin_seq);

	public AdminDVO adm_login(AdminDVO aVO);
	
	public int listCount();
	
//	public List<admin_boardVO> selectList(PagingVO pg);
}
