package com.mycompany.mypudingapp.admin.vo;

public class AdminDVO {
	
	private String admin_id;
	private String admin_pw;
	private String admin_name;
	private String admin_regdate;
	
	public AdminDVO() {
		
	}

	public AdminDVO(String admin_id, String admin_pw, String admin_name, String admin_regdate) {
		super();
		this.admin_id = admin_id;
		this.admin_pw = admin_pw;
		this.admin_name = admin_name;
		this.admin_regdate = admin_regdate;
	}

	public String getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(String admin_id) {
		this.admin_id = admin_id;
	}

	public String getAdmin_pw() {
		return admin_pw;
	}

	public void setAdmin_pw(String admin_pw) {
		this.admin_pw = admin_pw;
	}

	public String getAdmin_name() {
		return admin_name;
	}

	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}

	public String getAdmin_regdate() {
		return admin_regdate;
	}

	public void setAdmin_regdate(String admin_regdate) {
		this.admin_regdate = admin_regdate;
	}

}
