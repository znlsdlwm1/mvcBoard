package com.mycompany.mypudingapp.admin.vo;

public class admin_boardVO {
	private int admin_seq ; 
	private String admin_title;
	private String admin_content;
	private String admin_writer;
	private String admin_regdate;
	private int admin_viewcnt;
	private int admin_email;
	private int admin_phonenum;
	private String admin_id;
	
	public admin_boardVO() {
		
	}

	public admin_boardVO(int admin_seq, String admin_title, String admin_content, String admin_writer, String admin_regdate, int admin_viewcnt, int admin_email,
			int admin_phonenum, String admin_id) {
		super();
		this.admin_seq = admin_seq;
		this.admin_title = admin_title;
		this.admin_content = admin_content;
		this.admin_writer = admin_writer;
		this.admin_regdate = admin_regdate;
		this.admin_viewcnt = admin_viewcnt;
		this.admin_email = admin_email;
		this.admin_phonenum = admin_phonenum;
		this.admin_id = admin_id;
	}

	public int getAdmin_seq() {
		return admin_seq;
	}

	public void setAdmin_seq(int admin_seq) {
		this.admin_seq = admin_seq;
	}

	public String getAdmin_title() {
		return admin_title;
	}

	public void setAdmin_title(String admin_title) {
		this.admin_title = admin_title;
	}

	public String getAdmin_content() {
		return admin_content;
	}

	public void setAdmin_content(String admin_content) {
		this.admin_content = admin_content;
	}

	public String getAdmin_writer() {
		return admin_writer;
	}

	public void setAdmin_writer(String admin_writer) {
		this.admin_writer = admin_writer;
	}

	public String getAdmin_regdate() {
		return admin_regdate;
	}

	public void setAdmin_regdate(String admin_regdate) {
		this.admin_regdate = admin_regdate;
	}

	public int getAdmin_viewcnt() {
		return admin_viewcnt;
	}

	public void setAdmin_viewcnt(int admin_viewcnt) {
		this.admin_viewcnt = admin_viewcnt;
	}

	public int getAdmin_email() {
		return admin_email;
	}

	public void setAdmin_email(int admin_email) {
		this.admin_email = admin_email;
	}

	public int getAdmin_phonenum() {
		return admin_phonenum;
	}

	public void setAdmin_phonenum(int admin_phonenum) {
		this.admin_phonenum = admin_phonenum;
	}

	public String getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(String admin_id) {
		this.admin_id = admin_id;
	}

	
	
	
	
}
