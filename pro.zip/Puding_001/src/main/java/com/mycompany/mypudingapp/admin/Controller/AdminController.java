package com.mycompany.mypudingapp.admin.Controller;


import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.ibatis.annotations.Param;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.mycompany.mypudingapp.admin.Service.AdminService;
import com.mycompany.mypudingapp.admin.vo.AdminDVO;
import com.mycompany.mypudingapp.admin.vo.admin_boardVO;
import com.mycompany.mypudingapp.domain.PagingVO;

@Controller
@RequestMapping("/admin")
public class AdminController {

	private Logger logger = LoggerFactory.getLogger(AdminController.class);
	
	@Autowired
	private AdminService adminService;
	
	//리스트
	@RequestMapping(value = "/adm_list", method = RequestMethod.GET)
	public String adm_list(Model model, HttpServletRequest req,
			@RequestParam Map<String, Object> param) {
		//map object로 형변을 받기때문에 받고자하는 int타입으로
		
		
		int totalCount = adminService.listCount();
		
		int currentPage = 0;
		if ( param.get("page") == null ) {
			currentPage = 1;
		} else {
			currentPage = Integer.parseInt(param.get("page").toString());
		}
		
		int range = 0;
		if (param.get("range") == null) {
			range = 1;
		} else {
			range = Integer.parseInt(param.get("range").toString());
		}
		
		PagingVO vo = new PagingVO();
		
		vo.pageInfo(currentPage, range, totalCount);
		
		model.addAttribute("pagination", vo);
		
		model.addAttribute("viewAll", adminService.adm_list(vo));
		
		return "/admin/adm_list";
	}
	
//		@RequestMapping(value = "/adm_list", method = RequestMethod.GET)
//		public String adm_list(PagingVO pg, Model model
//								, @RequestParam(value="nowPage", required=false)String nowPage
//								, @RequestParam(value="cntPerPage", required=false)String cntPerPage) {
//			model.addAttribute("viewAll", adminService.adm_list(pg));
//			
//			PagingVO paging = new PagingVO();
//			
//			model.addAttribute("paging", paging);
//			
//			int total = adminService.listCount();
//			if (nowPage == null && cntPerPage == null) {
//				nowPage = "1";
//				cntPerPage = "5";
//			} else if (nowPage == null) {
//				nowPage = "1";
//			} else if (cntPerPage == null) {
//				cntPerPage = "5";
//			}
//			pg = new PagingVO(total, Integer.parseInt(nowPage), Integer.parseInt(cntPerPage));
//			model.addAttribute("paging", pg);
//			model.addAttribute("viewAll", adminService.selectList(pg));
//			
//			return "/admin/adm_listPaging";
//		}
	
	//상세
	@RequestMapping(value = "/adm_viewDetail", method = RequestMethod.GET, produces = "application/text; charset=utf8")
	public String adm_viewDetail(Model model,
							@RequestParam("admin_seq") int admin_seq
							) {
		
		System.out.println("board_sequence ======================================= ");
		System.out.println(admin_seq);
		model.addAttribute("admin_tbl_board", adminService.adm_viewDetail(admin_seq));
		
		return "/admin/adm_viewDetail";
	}
	
	//등록
	@RequestMapping("/adm_insert")
	public String adm_insert () {
		
		return "/admin/adm_insert";
	}
	
	// 등록폼
	@RequestMapping(value="/adm_from")
	public String adm_insert(Model model, admin_boardVO vo,
							@Param("admin_title") String admin_title,
							@Param("admin_writer") String admin_writer,
							@Param("admin_content") String admin_content) {
		//from으로 전달할때
		
		System.out.println("admin_title"+admin_title);
		System.out.println("admin_writer"+admin_writer);
		System.out.println("admin_content"+admin_content);
		adminService.adm_insert(admin_title,admin_writer,admin_content);
		System.out.println("ddddd");
		
		return "redirect:/admin/adm_list";
	}
	
	//수정
	@RequestMapping("/adm_update")
	public String adm_update(Model model,
							@RequestParam("admin_seq") int admin_seq) {
		System.out.println("admin update ====> start ! ");
		System.out.println(admin_seq);
		
		model.addAttribute("admin_tbl_board", adminService.adm_viewDetail(admin_seq));
		model.addAttribute("admin_seq",admin_seq);
		
		return "/admin/adm_update";
	}
	
	//수정폼
	@RequestMapping("/adm_doupdate")
	public String adm_doupdate (Model model, admin_boardVO vo,
							@Param("admin_seq") int admin_seq,
							@Param("admin_title") String admin_title,
							@Param("admin_writer") String admin_writer,
							@Param("admin_content") String admin_content) {
							// 바꾼내용을 파라미터러 보낸다
		System.out.println("do admin update !!!");
							
		System.out.println(admin_seq);
		System.out.println("admin_title ===> " + admin_title);
		System.out.println("admin_title ===> " + admin_writer);
		System.out.println("admin_title ===> " + admin_content);
		adminService.adm_doupdate(admin_seq,admin_title,admin_writer,admin_content);
		
		return "redirect:/admin/adm_list";
	}
			// 바꾼내용을 파라미터러 보낸다
	
	//삭제
	@RequestMapping("adm_delete")
	public String adm_delete(HttpServletRequest req, admin_boardVO vo, @Param("admin_seq") int admin_seq) {
		
		adminService.adm_delete(admin_seq);
		
		
		
		return "redirect:/admin/adm_list";
	}
	
	//로그인
	@RequestMapping(value = "/adm_login", method = RequestMethod.POST)
	public AdminDVO adm_login(AdminDVO aVO,HttpServletRequest req) {
		
		//해당 사용자에 대한 정보를 저장하는 방법
		HttpSession session = req.getSession();
		AdminDVO ad = adminService.adm_login(aVO);
		
		return ad;
	}
	
}
